import  cloudinary  from 'cloudinary';

const Cloudinary=cloudinary.v2;
// Configuration 
Cloudinary.config({
  cloud_name: "dtdbex0na",
  api_key: "498395899475227",
  api_secret: "Nsi0KPTmODO8Kf34bwgAykL-ozo"
});
export default Cloudinary;