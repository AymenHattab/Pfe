-- DropIndex
DROP INDEX `commande_code_key` ON `commande`;
