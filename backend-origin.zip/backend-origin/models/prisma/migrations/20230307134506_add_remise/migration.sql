-- AlterTable
ALTER TABLE `produit` ADD COLUMN `remise` INTEGER NULL;
